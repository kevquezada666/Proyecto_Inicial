import javax.swing.JOptionPane;

public class Simulador {
    private Torre torre;
    private boolean visible;

    public Simulador() {
        visible = false;
    }

    public void ejecutar() {
        String menu = "1. Crear torre\n2. Añadir taza\n3. Eliminar taza\n4. Añadir tapa\n"
                    + "5. Eliminar tapa\n6. Ordenar (mayor a menor)\n7. Invertir orden\n"
                    + "8. Altura apilada\n9. Info tazas tapadas y conteo\n10. Mostrar/Ocultar simulador\n0. Salir";
        while (true) {
            String res = JOptionPane.showInputDialog(menu);
            if (res == null) break;           // Cancelar
            if (res.trim().equals("")) continue;   // Si está vacío, vuelve a mostrar menú

            int op;
            try {
                op = Integer.parseInt(res);
            } catch (NumberFormatException e) {
                continue; // Si no es número, vuelve al menú
            }
            if (op == 0) break;
            switch (op) {
                case 1: crearTorre(); break;
                case 2: anadirTaza(); break;
                case 3: eliminarTaza(); break;
                case 4: anadirTapa(); break;
                case 5: eliminarTapa(); break;
                case 6: ordenar(); break;
                case 7: invertir(); break;
                case 8: mostrarAltura(); break;
                case 9: mostrarInfo(); break;
                case 10: toggleVisibilidad(); break;
                default: break;
            }
        }
    }

    private void crearTorre() {
        String sAncho = JOptionPane.showInputDialog("Ancho de la torre:");
        String sAlto  = JOptionPane.showInputDialog("Alto de la torre:");
        if (sAncho == null || sAlto == null) return;
        int ancho = Integer.parseInt(sAncho);
        int alto  = Integer.parseInt(sAlto);
        torre = new Torre(ancho, alto);
    }

    private void anadirTaza() {
        if (torre == null) {
            if (visible) JOptionPane.showMessageDialog(null, "Debe crear la torre primero");
            return;
        }
        String color = JOptionPane.showInputDialog("Color de la taza:");
        String sAlto  = JOptionPane.showInputDialog("Altura de la taza:");
        if (color == null || sAlto == null) return;
        int alto = Integer.parseInt(sAlto);
        String msg = torre.addTaza(alto, color);
        if (msg != null && visible) JOptionPane.showMessageDialog(null, msg);
    }

    private void eliminarTaza() {
        if (torre == null) {
            if (visible) JOptionPane.showMessageDialog(null, "Debe crear la torre primero");
            return;
        }
        String color = JOptionPane.showInputDialog("Color de la taza a eliminar:");
        if (color == null) return;
        String msg = torre.removeTaza(color);
        if (msg != null && visible) JOptionPane.showMessageDialog(null, msg);
    }

    private void anadirTapa() {
        if (torre == null) {
            if (visible) JOptionPane.showMessageDialog(null, "Debe crear la torre primero");
            return;
        }
        String color = JOptionPane.showInputDialog("Color de la tapa:");
        if (color == null) return;
        String msg = torre.addTapa(color);
        if (msg != null && visible) JOptionPane.showMessageDialog(null, msg);
    }

    private void eliminarTapa() {
        if (torre == null) {
            if (visible) JOptionPane.showMessageDialog(null, "Debe crear la torre primero");
            return;
        }
        String color = JOptionPane.showInputDialog("Color de la tapa a eliminar:");
        if (color == null) return;
        String msg = torre.removeTapa(color);
        if (msg != null && visible) JOptionPane.showMessageDialog(null, msg);
    }

    private void ordenar() {
        if (torre != null) {
            torre.ordenarPorAlturaDesc();
        }
    }

    private void invertir() {
        if (torre != null) {
            torre.invertirOrden();
        }
    }

    private void mostrarAltura() {
        if (torre != null) {
            int alt = torre.getAlturaTotal();
            if (visible) JOptionPane.showMessageDialog(null, "Altura total: " + alt);
        }
    }

    private void mostrarInfo() {
        if (torre != null) {
            String tapadas = torre.consultarTazasTapadas();
            String conteo  = torre.consultarCantidadElementos();
            if (visible) {
                JOptionPane.showMessageDialog(null, tapadas + "\n" + conteo);
            }
        }
    }

    private void toggleVisibilidad() {
        if (torre != null) {
            visible = !visible;
            Canvas canvas = Canvas.getCanvas();
            canvas.setVisible(visible);
        }
    }
}
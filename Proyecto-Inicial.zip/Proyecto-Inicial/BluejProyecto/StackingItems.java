public class StackingItems {
    public static void main(String[] args) {
        Simulador sim = new Simulador();
        sim.ejecutar();
    }
}
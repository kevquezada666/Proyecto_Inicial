import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Torre {
    private int ancho;
    private int alturaMax;
    private List<Object> items; // Contiene Taza y Tapa

    public Torre(int ancho, int altura) {
        this.ancho = ancho;
        this.alturaMax = altura;
        items = new ArrayList<>();
    }

    public String addTaza(int altura, String color) {
        // Verificar color único entre tazas y tapas
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.getColor().equals(color))
                    return "Ya existe una taza de color " + color;
            } else if (obj instanceof Tapa) {
                Tapa tp = (Tapa) obj;
                if (tp.getColor().equals(color))
                    return "Ya existe una tapa de color " + color;
            }
        }
        // Crear nueva taza
        Taza nueva = new Taza(altura, color);
        // Si hay tapa suelta del mismo color, se asocia a la taza
        Iterator<Object> it = items.iterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof Tapa) {
                Tapa tp = (Tapa) obj;
                if (tp.getColor().equals(color)) {
                    nueva.setTapa(tp);
                    it.remove();
                    break;
                }
            }
        }
        // Verificar que quepa en altura
        int total = getAlturaTotal() + nueva.getHeight();
        if (nueva.tieneTapa()) total += nueva.getTapa().getHeight();
        if (total > alturaMax) {
            return "No cabe la nueva taza en la torre";
        }
        items.add(nueva);
        return null;
    }

    public String removeTaza(String color) {
        Iterator<Object> it = items.iterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.getColor().equals(color)) {
                    it.remove();
                    return null;
                }
            }
        }
        return "No existe la taza de color " + color;
    }

    public String addTapa(String color) {
        // Verificar no duplicar tapa del mismo color
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.tieneTapa() && t.getTapa().getColor().equals(color))
                    return "Ya existe una tapa de color " + color;
            } else if (obj instanceof Tapa) {
                Tapa tp = (Tapa) obj;
                if (tp.getColor().equals(color))
                    return "Ya existe una tapa de color " + color;
            }
        }
        // Crear nueva tapa
        Tapa nueva = new Tapa(color);
        // Si hay taza del mismo color sin tapa, se coloca sobre ella
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.getColor().equals(color) && !t.tieneTapa()) {
                    // Verificar altura
                    if (getAlturaTotal() + nueva.getHeight() > alturaMax)
                        return "No cabe la tapa en la torre";
                    t.setTapa(nueva);
                    return null;
                }
            }
        }
        // Si no se asocia, se deja la tapa sola
        if (getAlturaTotal() + nueva.getHeight() > alturaMax)
            return "No cabe la tapa en la torre";
        items.add(nueva);
        return null;
    }

    public String removeTapa(String color) {
        // Buscar tapa suelta
        Iterator<Object> it = items.iterator();
        while (it.hasNext()) {
            Object obj = it.next();
            if (obj instanceof Tapa) {
                Tapa tp = (Tapa) obj;
                if (tp.getColor().equals(color)) {
                    it.remove();
                    return null;
                }
            }
        }
        // Buscar taza que tenga esa tapa
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.tieneTapa() && t.getTapa().getColor().equals(color)) {
                    t.removeTapa();
                    return null;
                }
            }
        }
        return "No existe la tapa de color " + color;
    }

    public void ordenarPorAlturaDesc() {
        // Combinar lista de elementos (tazas y tapas) y ordenar
        List<Object> all = new ArrayList<>(items);
        all.sort(new Comparator<Object>() {
            public int compare(Object o1, Object o2) {
                int h1 = 0, h2 = 0;
                if (o1 instanceof Taza) {
                    Taza t1 = (Taza) o1;
                    h1 = t1.getHeight();
                    if (t1.tieneTapa()) h1 += t1.getTapa().getHeight();
                } else {
                    h1 = ((Tapa) o1).getHeight();
                }
                if (o2 instanceof Taza) {
                    Taza t2 = (Taza) o2;
                    h2 = t2.getHeight();
                    if (t2.tieneTapa()) h2 += t2.getTapa().getHeight();
                } else {
                    h2 = ((Tapa) o2).getHeight();
                }
                return h2 - h1;
            }
        });
        // Reapilar solo los que quepan en altura
        items.clear();
        int acum = 0;
        for (Object obj : all) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                int bloque = t.getHeight() + (t.tieneTapa() ? t.getTapa().getHeight() : 0);
                if (acum + bloque <= alturaMax) {
                    items.add(t);
                    acum += bloque;
                }
            } else {
                Tapa tp = (Tapa) obj;
                if (acum + tp.getHeight() <= alturaMax) {
                    items.add(tp);
                    acum += tp.getHeight();
                }
            }
        }
    }

    public void invertirOrden() {
        List<Object> all = new ArrayList<>(items);
        Collections.reverse(all);
        items.clear();
        int acum = 0;
        for (Object obj : all) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                int bloque = t.getHeight() + (t.tieneTapa() ? t.getTapa().getHeight() : 0);
                if (acum + bloque <= alturaMax) {
                    items.add(t);
                    acum += bloque;
                }
            } else {
                Tapa tp = (Tapa) obj;
                if (acum + tp.getHeight() <= alturaMax) {
                    items.add(tp);
                    acum += tp.getHeight();
                }
            }
        }
    }

    public int getAlturaTotal() {
        int total = 0;
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                total += t.getHeight();
                if (t.tieneTapa()) total += t.getTapa().getHeight();
            } else {
                total += ((Tapa) obj).getHeight();
            }
        }
        return total;
    }

    public String consultarTazasTapadas() {
        String res = "Tazas tapadas: ";
        for (Object obj : items) {
            if (obj instanceof Taza) {
                Taza t = (Taza) obj;
                if (t.tieneTapa()) {
                    res += t.getColor() + " ";
                }
            }
        }
        return res.trim();
    }

    public String consultarCantidadElementos() {
        int nT = 0, nL = 0;
        for (Object obj : items) {
            if (obj instanceof Taza) {
                nT++;
                if (((Taza) obj).tieneTapa()) nL++;
            } else {
                nL++;
            }
        }
        return "Elementos: " + nT + " tazas, " + nL + " tapas";
    }
}


public class Tapa {
    private static final int ALTURA = 1;
    private String color;
    private Rectangle shape;
    private int topY;

    public Tapa(String color) {
        this.color = color;
        shape = new Rectangle();
        shape.changeColor(color);
        shape.changeSize(30, ALTURA * 5);  // altura fija de 1 cm
        shape.moveHorizontal(-175);
        topY = 120;
    }

    public int getHeight() { return ALTURA; }
    public String getColor() { return color; }
    public Rectangle getShape() { return shape; }
    public int getTop() { return topY; }
    public void setTop(int y) { topY = y; }
}



public class Taza {
    private int altura;
    private String color;
    private Tapa tapa;
    private Rectangle shape;
    private int topY;

    public Taza(int altura, String color) {
        this.altura = altura;
        this.color = color;
        this.tapa = null;
        shape = new Rectangle();
        shape.changeColor(color);
        shape.changeSize(30, altura * 5);   // 5 px por cm de altura
        shape.moveHorizontal(-175);        // Centrar en X (desplazamiento fijo)
        topY = 120; // posición inicial Y por defecto
    }

    public int getHeight() { return altura; }
    public String getColor() { return color; }
    public boolean tieneTapa() { return tapa != null; }
    public void setTapa(Tapa t) { tapa = t; }
    public Tapa getTapa() { return tapa; }
    public void removeTapa() { tapa = null; }
    public Rectangle getShape() { return shape; }
    public int getTop() { return topY; }
    public void setTop(int y) { topY = y; }
}